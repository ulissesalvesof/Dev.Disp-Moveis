package com.example.planner.ui.theme.screens

import android.util.Log
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.foundation.clickable
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.planner.data.StudyTask

// Definição de dados da tarefa (caso não tenha sido definida em outro lugar)
data class StudyTask(
    val id: String,
    val title: String,
    val description: String,
    val completed: Boolean
)

@Composable
fun TaskListScreen(taskList: List<StudyTask>, onTaskClick: (StudyTask) -> Unit) {
    // Verifique o tamanho da lista para depuração
    Log.d("TaskListScreen", "taskList size: ${taskList.size}")

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp)
    ) {
        // Verifique se a lista não está vazia antes de iterar
        if (taskList.isEmpty()) {
            item {
                Text("Nenhuma tarefa disponível.", modifier = Modifier.fillMaxWidth(), fontSize = 18.sp)
            }
        } else {
            items(taskList) { task ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable { onTaskClick(task) },
                    elevation = CardDefaults.cardElevation(4.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(task.title, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        Text(task.description, fontSize = 16.sp)
                    }
                }
            }
        }
    }
}
