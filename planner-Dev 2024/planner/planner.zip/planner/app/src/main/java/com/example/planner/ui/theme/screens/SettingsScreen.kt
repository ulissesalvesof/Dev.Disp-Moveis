package com.example.planner.ui.theme.screens

import android.content.Context
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope

// Definindo o DataStore em nível de contexto
private val Context.dataStore by preferencesDataStore(name = "settings")

@Composable
fun SettingsScreen(context: Context) {
    val scope = rememberCoroutineScope()

    // Corrigido: criando o estado de darkModeEnabled sem 'by'
    val darkModeEnabled = remember { mutableStateOf(false) }

    // Layout da tela de configurações
    Column(modifier = Modifier.padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Modo Escuro")
            Switch(
                checked = darkModeEnabled.value,
                onCheckedChange = {
                    darkModeEnabled.value = it
                    scope.launch {
                        context.dataStore.edit { preferences ->
                            preferences[booleanPreferencesKey("dark_mode")] = it
                        }
                    }
                }
            )
        }
    }
}
