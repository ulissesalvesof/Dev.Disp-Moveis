package com.example.planner.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map



private val Context.dataStore by preferencesDataStore("study_planner")

data class StudyTask(
    val id: String,
    val title: String,
    val description: String,
    val completed: Boolean
)
object TaskManager {
    private val TASKS_KEY = stringSetPreferencesKey("tasks")

    suspend fun addTask(context: Context, task: StudyTask) {
        context.dataStore.edit { preferences ->
            val tasks = preferences[TASKS_KEY] ?: emptySet()
            preferences[TASKS_KEY] = tasks + "${task.id},${task.title},${task.description},${task.completed}"
        }
    }

    fun getTasks(context: Context) = context.dataStore.data.map { preferences ->
        val tasks = preferences[TASKS_KEY] ?: emptySet()
        tasks.map {
            val (id, title, description, completed) = it.split(",")
            StudyTask(id, title, description, completed.toBoolean())
        }
    }
}
