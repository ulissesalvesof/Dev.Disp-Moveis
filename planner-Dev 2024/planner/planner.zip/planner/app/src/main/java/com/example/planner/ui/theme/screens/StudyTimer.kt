package com.example.planner.ui.theme.screens

import android.text.Layout
import androidx.compose.foundation.layout.Column
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import kotlinx.coroutines.delay
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay


@Composable
fun StudyTimer(onTimerEnd: () -> Unit) {
    var timeLeft by remember { mutableStateOf(25 * 60) } // 25 minutos (em segundos)

    LaunchedEffect(timeLeft) {
        if (timeLeft > 0) {
            delay(1000L) // Espera 1 segundo
            timeLeft--
        } else {
            onTimerEnd() // Chama o callback quando o tempo terminar
        }
    }

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Tempo Restante: ${timeLeft / 60}:${timeLeft % 60}",
            style = MaterialTheme.typography.titleLarge
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = { timeLeft = 25 * 60 },
            modifier = Modifier.padding(16.dp)
        ) {
            Text("Reiniciar")
        }
    }
}