package com.example.planner

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.planner.ui.theme.screens.SettingsScreen
import com.example.planner.ui.theme.StudyPlannerTheme
import com.example.planner.ui.theme.screens.TaskListScreen
import com.example.planner.ui.theme.screens.StudyTimer
import com.example.planner.data.StudyTask

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            StudyPlannerTheme {
                val navController = rememberNavController()

                // Obtém o contexto atual
                val context = LocalContext.current

                // Criando uma lista de tarefas de exemplo
                val taskList = listOf(
                    StudyTask("1", "Estudar Matemática", "Revisar álgebra", false),
                    StudyTask("2", "Ler Livro", "Ler capítulo 3 do livro de física", false)
                )

                NavHost(navController = navController, startDestination = "task_list") {
                    composable("task_list") {
                        // Passa a lista de tarefas e a função onTaskClick para TaskListScreen
                        TaskListScreen(
                            taskList = taskList,
                            onTaskClick = { task ->
                                // Ação que pode ser executada quando a tarefa for clicada
                                println("Tarefa clicada: ${task.title}")
                            }
                        )
                    }
                    composable("study_timer") {
                        StudyTimer(onTimerEnd = {
                            // Lógica para executar quando o tempo acabar (ex: mostrar um alerta)
                        })
                    }
                    composable("settings") {
                        // Passa o contexto para a SettingsScreen
                        SettingsScreen(context = context)
                    }
                }
            }
        }
    }
}
